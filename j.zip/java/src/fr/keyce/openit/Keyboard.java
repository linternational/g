package fr.keyce.openit;

public class Keyboard {
	@Override
	public String toString() {
		return "Keyboard";
	}
}
