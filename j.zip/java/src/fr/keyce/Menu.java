package fr.keyce;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import fr.keyce.openit.Computer;






public class Menu extends JFrame {
    
    private Computer[] computers = new Computer[0];
    
    private JPanel mainMenu;
    private JPanel addComputerMenu;
    private JPanel modifyComputerMenu;
    private JPanel removeComputerMenu;
    
    public Menu() {
        setTitle("Menu");
        setSize(630,720);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        mainMenu = new JPanel();
        mainMenu.setLayout(new GridLayout(5, 1));
        
        JButton buttonAddComputer = new JButton("Ajouter un ordinateur");
        JButton buttonDelComputer = new JButton("Supprimer un ordinateur");
        JButton buttonModifyComputer = new JButton("Modifier un ordinateur");
        JButton buttonDisplayComputers = new JButton("Afficher les ordinateurs");
        JButton buttonExit = new JButton("Quitter");

        buttonAddComputer.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setVisiblePanel(addComputerMenu);
            }
        });

        buttonDelComputer.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setVisiblePanel(removeComputerMenu);
            }
        });
        
        buttonModifyComputer.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setVisiblePanel(modifyComputerMenu);
            }
        });
        
        buttonDisplayComputers.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                displayComputers();
            }
        });
        
        buttonExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        mainMenu.add(buttonAddComputer);
        mainMenu.add(buttonDelComputer);
        mainMenu.add(buttonModifyComputer);
        mainMenu.add(buttonDisplayComputers);
        mainMenu.add(buttonExit);

        add(mainMenu);
        createAddComputerMenu();
        createModifyComputerMenu();
        createRemoveComputerMenu();
    }

    private void createAddComputerMenu() {
        addComputerMenu = new JPanel();
        addComputerMenu.setLayout(new GridLayout(3, 2));

        JLabel nameLabel = new JLabel("Nom de l'ordinateur :");
        JTextField nameField = new JTextField();
        JLabel serialLabel = new JLabel("Numéro de série :");
        JTextField serialField = new JTextField();
        JButton addButton = new JButton("Ajouter");
        JButton backButton = new JButton("Retour");

        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();
                String serialNumber = serialField.getText();
                Computer computer = addComputer();
                computer.setName(name);
                computer.setSerialNumber(serialNumber);
                JOptionPane.showMessageDialog(null, "Ordinateur ajouté avec succès !");
                setVisiblePanel(mainMenu);
            }
        });

        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setVisiblePanel(mainMenu);
            }
        });

        addComputerMenu.add(nameLabel);
        addComputerMenu.add(nameField);
        addComputerMenu.add(serialLabel);
        addComputerMenu.add(serialField);
        addComputerMenu.add(addButton);
        addComputerMenu.add(backButton);
        
        add(addComputerMenu);
    }

    private void createModifyComputerMenu() {
        modifyComputerMenu = new JPanel();
        modifyComputerMenu.setLayout(new GridLayout(3, 2));

        JLabel idLabel = new JLabel("ID de l'ordinateur :");
        JTextField idField = new JTextField();
        JLabel nameLabel = new JLabel("Nom de l'ordinateur :");
        JTextField nameField = new JTextField();
        JLabel serialLabel = new JLabel("Numéro de série :");
        JTextField serialField = new JTextField();
        JButton modifyButton = new JButton("Modifier");
        JButton backButton = new JButton("Retour");

        modifyButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int id = Integer.parseInt(idField.getText());
                String name = nameField.getText();
                String serialNumber = serialField.getText();
                if (id >= 0 && id < computers.length) {
                    computers[id].setName(name);
                    computers[id].setSerialNumber(serialNumber);
                    JOptionPane.showMessageDialog(null, "Ordinateur modifié avec succès !");
                } else {
                    JOptionPane.showMessageDialog(null, "ID invalide !");
                }
                setVisiblePanel(mainMenu);
            }
        });

        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setVisiblePanel(mainMenu);
            }
        });

        modifyComputerMenu.add(idLabel);
        modifyComputerMenu.add(idField);
        modifyComputerMenu.add(nameLabel);
        modifyComputerMenu.add(nameField);
        modifyComputerMenu.add(serialLabel);
        modifyComputerMenu.add(serialField);
        modifyComputerMenu.add(modifyButton);
        modifyComputerMenu.add(backButton);

        add(modifyComputerMenu);
    }

    private void createRemoveComputerMenu() {
        removeComputerMenu = new JPanel();
        removeComputerMenu.setLayout(new GridLayout(2, 2));

        JLabel idLabel = new JLabel("ID de l'ordinateur :");
        JTextField idField = new JTextField();
        JButton removeButton = new JButton("Supprimer");
        JButton backButton = new JButton("Retour");

        removeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int id = Integer.parseInt(idField.getText());
                if (id >= 0 && id < computers.length) {
                    removeComputer(id);
                    JOptionPane.showMessageDialog(null, "Ordinateur supprimé avec succès !");
                } else {
                    JOptionPane.showMessageDialog(null, "ID invalide !");
                }
                setVisiblePanel(mainMenu);
            }
        });

        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setVisiblePanel(mainMenu);
            }
        });

        removeComputerMenu.add(idLabel);
        removeComputerMenu.add(idField);
        removeComputerMenu.add(removeButton);
        removeComputerMenu.add(backButton);

        add(removeComputerMenu);
    }

    private void displayComputers() {
        StringBuilder computersList = new StringBuilder("Liste des ordinateurs :\n");
        for (int i = 0; i < computers.length; i++) {
            computersList.append(i).append(" - ").append(computers[i]).append("\n");
        }
        JOptionPane.showMessageDialog(null, computersList.toString());
    }

    private void setVisiblePanel(JPanel panel) {
        mainMenu.setVisible(false);
        addComputerMenu.setVisible(false);
        modifyComputerMenu.setVisible(false);
        removeComputerMenu.setVisible(false);
        panel.setVisible(true);
        setContentPane(panel);
        revalidate();
        repaint();
    }

    private Computer addComputer() {
        Computer[] newTab = new Computer[computers.length + 1];
        System.arraycopy(computers, 0, newTab, 0, computers.length);
        computers = newTab;
        computers[computers.length - 1] = new Computer();
        return computers[computers.length - 1];
    }

    private void removeComputer(int position) {
        Computer[] newTab = new Computer[computers.length - 1];
        for (int i = 0, j = 0; i < computers.length; i++) {
            if (i != position) {
                newTab[j++] = computers[i];
            }
        }
        computers = newTab;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Menu().setVisible(true);
            }
        });
    }
}
